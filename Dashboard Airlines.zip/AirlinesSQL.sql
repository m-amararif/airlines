--1. What is the total passenger of the dataset?
SELECT COUNT(*) as total_passenger FROM airlinesdata

--2. What is the total country in the dataset?
SELECT COUNT(DISTINCT(Country_Name)) as total_country from airlinesdata

--3. What is the total nationality in the dataset?
SELECT COUNT(DISTINCT([Nationality])) AS total_nationality from airlinesdata

--4. What is the average passenger per country?
SELECT (COUNT(*)/COUNT(DISTINCT(Country_Name))) as avg_passenger from airlinesdata

--5. What is the daily trend for passenger?
SELECT day_name, COUNT(*) as total_passenger
from airlinesdata
group by day_name
order by
CASE
	when day_name = 'Monday' THEN 1
	when day_name = 'Tuesday' THEN 2
	when day_name = 'Wednesday' THEN 3
	when day_name = 'Thursday' THEN 4
	when day_name = 'Friday' THEN 5
	when day_name = 'Saturday' THEN 6
	when day_name = 'Sunday' THEN 7
	END;

--6. What is the monthly trend for passenger?
select month_name, COUNT(*) as total_passenger
from airlinesdata
group by month_name
order by
case
	when month_name = 'Jan' then 1
	when month_name = 'Feb' then 2
	when month_name = 'Mar' then 3
	when month_name = 'Apr' then 4
	when month_name = 'May' then 5
	when month_name = 'Jun' then 6
	when month_name = 'Jul' then 7
	when month_name = 'Aug' then 8
	when month_name = 'Sep' then 9
	when month_name = 'Oct' then 10
	when month_name = 'Nov' then 11
	when month_name = 'Dec' then 12
end;

--7. How many total and percentages of passenger by their gender?
select gender, count(*) as total_passenger, cast((count(*)*100.0/sum(count(*)) over()) as decimal (10,2)) as avg_passenger_per_country
from airlinesdata
group by Gender

--8. How many total and percentage of passenger according to their flight status?
select Flight_Status, count(Flight_Status) as total_passenger, cast((count(*)*100.0/sum(count(*)) over()) as decimal (10,2)) as percentages_flight_status
from airlinesdata
group by Flight_Status

--9. What is the total passenger by their country and show only top 10 of it
select top 10 Country_Name, count(Country_Name) as total_passenger
from airlinesdata
group by Country_Name
order by total_passenger desc


